// api.js
// A thin wrapper around fetch() for talking to the backend.
// Centralizing this means the base URL and cookie settings only live in
// one place.

const API_BASE_URL = 'http://localhost:3000/api';

// Generic request helper.
// - Always sends credentials: 'include' so the HttpOnly JWT cookie is sent.
// - Throws an Error with the backend's message so callers can show it.
async function request(path, options = {}) {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    credentials: 'include', // send/receive the auth cookie
    headers: {
      'Content-Type': 'application/json',
      ...options.headers,
    },
    ...options,
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(data.error || 'Something went wrong. Please try again.');
  }

  return data;
}

export const authApi = {
  register(payload) {
    return request('/auth/register', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  login(payload) {
    return request('/auth/login', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  logout() {
    return request('/auth/logout', { method: 'POST' });
  },

  me() {
    return request('/auth/me', { method: 'GET' });
  },
};
