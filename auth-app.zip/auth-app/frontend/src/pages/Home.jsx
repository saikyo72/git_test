// Home.jsx
// Public landing page. Shows different calls-to-action depending on
// whether the visitor is already signed in.

import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

function Home() {
  const { isAuthenticated } = useAuth();

  return (
    <div className="page centered-content">
      <div className="hero">
        <h1>Welcome</h1>
        <p>
          A simple, secure place to sign up and sign in. Built with React, Express, and JWT
          authentication.
        </p>
        <div className="hero-actions">
          {isAuthenticated ? (
            <Link to="/dashboard" className="btn">
              Go to Dashboard
            </Link>
          ) : (
            <>
              <Link to="/signup" className="btn">
                Get Started
              </Link>
              <Link to="/signin" className="btn btn-secondary">
                Sign In
              </Link>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

export default Home;
