// Dashboard.jsx
// Protected page — only reachable when logged in (enforced by
// ProtectedRoute in App.jsx). Shows the user's info and a sign out button.

import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

function formatDate(isoString) {
  if (!isoString) return '';
  const date = new Date(isoString);
  return date.toLocaleDateString(undefined, {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
}

function Dashboard() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  async function handleSignOut() {
    await logout();
    navigate('/');
  }

  return (
    <div className="page centered-content">
      <div className="card dashboard-card">
        <h1 className="dashboard-greeting">Hello, {user?.username}!</h1>
        <p>Here's your account information.</p>

        <div className="dashboard-info">
          <div className="dashboard-info-row">
            <span className="dashboard-info-label">Email:</span>
            <span className="dashboard-info-value">{user?.email}</span>
          </div>
          <div className="dashboard-info-row">
            <span className="dashboard-info-label">Account created:</span>
            <span className="dashboard-info-value">{formatDate(user?.createdAt)}</span>
          </div>
        </div>

        <div className="dashboard-signout">
          <button onClick={handleSignOut} className="btn btn-secondary">
            Sign Out
          </button>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;
