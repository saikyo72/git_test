// ProtectedRoute.jsx
// Wraps a page and redirects to Sign In if the user isn't authenticated.
// While the initial auth check is in flight, shows a loading state instead
// of redirecting prematurely.

import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

function ProtectedRoute({ children }) {
  const { isAuthenticated, loading } = useAuth();

  if (loading) {
    return <div className="loading-screen">Checking your session…</div>;
  }

  if (!isAuthenticated) {
    return <Navigate to="/signin" replace />;
  }

  return children;
}

export default ProtectedRoute;
