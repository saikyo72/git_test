// FormInput.jsx
// A reusable labeled input with inline error display, used by both the
// Sign Up and Sign In forms so field styling/behavior stays consistent.

function FormInput({ label, id, error, ...inputProps }) {
  return (
    <div className="form-group">
      <label htmlFor={id} className="form-label">
        {label}
      </label>
      <input id={id} className={`form-input ${error ? 'has-error' : ''}`} {...inputProps} />
      {error && <div className="field-error">{error}</div>}
    </div>
  );
}

export default FormInput;
