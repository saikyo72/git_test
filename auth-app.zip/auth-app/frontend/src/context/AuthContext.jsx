// AuthContext.jsx
// Provides login state (user, loading) and auth actions (register, login,
// logout) to the entire app, so any component can call useAuth() instead
// of prop-drilling.

import { createContext, useContext, useEffect, useState } from 'react';
import { authApi } from '../services/api';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  // "loading" tracks the initial check of whether the user already has a
  // valid session (e.g. after a page refresh). Pages use this to avoid
  // flashing a "signed out" state before we actually know.
  const [loading, setLoading] = useState(true);

  // On first load, ask the backend "am I logged in?" using the cookie.
  useEffect(() => {
    async function checkSession() {
      try {
        const data = await authApi.me();
        setUser(data.user);
      } catch {
        // No valid session — that's fine, just stay logged out.
        setUser(null);
      } finally {
        setLoading(false);
      }
    }
    checkSession();
  }, []);

  async function register({ username, email, password, confirmPassword }) {
    const data = await authApi.register({ username, email, password, confirmPassword });
    setUser(data.user);
    return data.user;
  }

  async function login({ email, password }) {
    const data = await authApi.login({ email, password });
    setUser(data.user);
    return data.user;
  }

  async function logout() {
    await authApi.logout();
    setUser(null);
  }

  const value = {
    user,
    loading,
    isAuthenticated: !!user,
    register,
    login,
    logout,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

// Custom hook for consuming the context — keeps imports clean elsewhere.
export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
