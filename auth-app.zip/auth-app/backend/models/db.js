// db.js
// Sets up a SQLite database file and makes sure the "users" table exists.
// We use better-sqlite3 because its API is synchronous, which keeps the
// rest of the codebase simple and easy to read for beginners (no need to
// wrap every query in a Promise).

const Database = require('better-sqlite3');
const path = require('path');

// The database file will be created automatically the first time the
// server runs, right next to this file.
const dbPath = path.join(__dirname, 'database.sqlite');
const db = new Database(dbPath);

// Create the users table if it doesn't already exist.
// - email is UNIQUE so two accounts can't share the same email.
// - password_hash stores the bcrypt hash, never the plain password.
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  )
`);

module.exports = db;
