// User.js
// A small "model" layer: every direct database query for users lives here,
// so the controller doesn't need to know any SQL.

const db = require('./db');

const User = {
  // Find a user by their email. Returns undefined if not found.
  findByEmail(email) {
    const stmt = db.prepare('SELECT * FROM users WHERE email = ?');
    return stmt.get(email);
  },

  // Find a user by their id. Returns undefined if not found.
  findById(id) {
    const stmt = db.prepare('SELECT * FROM users WHERE id = ?');
    return stmt.get(id);
  },

  // Create a new user. Expects the password to already be hashed.
  // Returns the newly created user row.
  create({ username, email, passwordHash }) {
    const stmt = db.prepare(
      'INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)'
    );
    const result = stmt.run(username, email, passwordHash);
    return User.findById(result.lastInsertRowid);
  },

  // Strip the password hash before sending a user object to the client.
  toSafeObject(user) {
    return {
      id: user.id,
      username: user.username,
      email: user.email,
      createdAt: user.created_at,
    };
  },
};

module.exports = User;
