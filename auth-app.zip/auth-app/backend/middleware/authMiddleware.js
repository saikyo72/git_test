// authMiddleware.js
// Protects routes by checking for a valid JWT in the HttpOnly cookie.
// If valid, attaches the decoded payload (user id) to req.userId.
// If missing/invalid, responds with 401 instead of calling next().

const jwt = require('jsonwebtoken');

function requireAuth(req, res, next) {
  const token = req.cookies.token;

  if (!token) {
    return res.status(401).json({ error: 'Not authenticated.' });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.userId = decoded.userId;
    next();
  } catch (err) {
    // Covers both an invalid signature and an expired token.
    return res.status(401).json({ error: 'Session expired or invalid. Please sign in again.' });
  }
}

module.exports = requireAuth;
