// server.js
// Entry point for the backend. Sets up Express, middleware, and routes.

require('dotenv').config();

const express = require('express');
const cors = require('cors');
const cookieParser = require('cookie-parser');

const authRoutes = require('./routes/authRoutes');

const app = express();
const PORT = process.env.PORT || 3000;

// --- Middleware ---

// Parses incoming JSON request bodies into req.body.
app.use(express.json());

// Parses cookies from incoming requests into req.cookies.
app.use(cookieParser());

// Allows the frontend (a different origin in dev, e.g. localhost:5173) to
// make requests to this API and send/receive cookies.
app.use(
  cors({
    origin: process.env.CLIENT_ORIGIN || 'http://localhost:5173',
    credentials: true,
  })
);

// --- Routes ---
app.use('/api/auth', authRoutes);

// Simple health check, useful for confirming the server is running.
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok' });
});

// Catch-all for unknown API routes.
app.use('/api', (req, res) => {
  res.status(404).json({ error: 'Route not found.' });
});

// --- Error handling ---
// Catches any error thrown/passed to next() that wasn't handled elsewhere.
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({ error: 'Internal server error.' });
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
