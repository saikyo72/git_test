// authRoutes.js
// Maps URLs + HTTP methods to controller functions.

const express = require('express');
const router = express.Router();

const { register, login, logout, me } = require('../controllers/authController');
const requireAuth = require('../middleware/authMiddleware');

router.post('/register', register);
router.post('/login', login);
router.post('/logout', logout);

// Protected: only accessible with a valid JWT cookie.
router.get('/me', requireAuth, me);

module.exports = router;
