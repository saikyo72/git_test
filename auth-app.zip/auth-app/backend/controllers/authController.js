// authController.js
// Contains the actual logic behind each auth endpoint.
// Routes just point here; this is where the work happens.

const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const User = require('../models/User');

const SALT_ROUNDS = 10;

// How we validate a properly-formed email without pulling in a library.
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// Creates a signed JWT for a given user id.
function generateToken(userId) {
  return jwt.sign({ userId }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '7d',
  });
}

// Sets the JWT as an HttpOnly cookie on the response.
// HttpOnly means client-side JS can't read it, which protects against XSS
// stealing the token. sameSite/secure settings help protect against CSRF.
function setTokenCookie(res, token) {
  res.cookie('token', token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production', // HTTPS only in prod
    sameSite: 'lax',
    maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days, in milliseconds
  });
}

// POST /api/auth/register
async function register(req, res) {
  try {
    const { username, email, password, confirmPassword } = req.body;

    // --- Validation ---
    if (!username || !email || !password || !confirmPassword) {
      return res.status(400).json({ error: 'All fields are required.' });
    }
    if (!EMAIL_REGEX.test(email)) {
      return res.status(400).json({ error: 'Please enter a valid email address.' });
    }
    if (password.length < 8) {
      return res.status(400).json({ error: 'Password must be at least 8 characters.' });
    }
    if (password !== confirmPassword) {
      return res.status(400).json({ error: 'Passwords do not match.' });
    }

    // Prevent duplicate accounts.
    const existingUser = User.findByEmail(email);
    if (existingUser) {
      return res.status(409).json({ error: 'An account with this email already exists.' });
    }

    // Hash the password before storing it. We never store plain text.
    const passwordHash = await bcrypt.hash(password, SALT_ROUNDS);

    const newUser = User.create({ username, email, passwordHash });

    // Automatically log the user in after registering.
    const token = generateToken(newUser.id);
    setTokenCookie(res, token);

    return res.status(201).json({ user: User.toSafeObject(newUser) });
  } catch (err) {
    console.error('Register error:', err);
    return res.status(500).json({ error: 'Something went wrong while creating your account.' });
  }
}

// POST /api/auth/login
async function login(req, res) {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required.' });
    }

    const user = User.findByEmail(email);
    // Same error message whether the email doesn't exist or the password is
    // wrong — this avoids revealing which one was incorrect to an attacker.
    if (!user) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    const passwordMatches = await bcrypt.compare(password, user.password_hash);
    if (!passwordMatches) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    const token = generateToken(user.id);
    setTokenCookie(res, token);

    return res.status(200).json({ user: User.toSafeObject(user) });
  } catch (err) {
    console.error('Login error:', err);
    return res.status(500).json({ error: 'Something went wrong while signing you in.' });
  }
}

// POST /api/auth/logout
function logout(req, res) {
  // Clearing the cookie is enough since we're not tracking sessions server-side.
  res.clearCookie('token');
  return res.status(200).json({ message: 'Signed out successfully.' });
}

// GET /api/auth/me
// Used by the frontend on page load to check "am I still logged in?"
function me(req, res) {
  const user = User.findById(req.userId);
  if (!user) {
    return res.status(404).json({ error: 'User not found.' });
  }
  return res.status(200).json({ user: User.toSafeObject(user) });
}

module.exports = { register, login, logout, me };
